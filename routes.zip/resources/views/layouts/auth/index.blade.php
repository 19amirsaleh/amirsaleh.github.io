@include('layouts.auth.header')

@yield('content')

@include('layouts.auth.footer')