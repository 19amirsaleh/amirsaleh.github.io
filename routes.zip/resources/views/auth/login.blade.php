@extends('layouts.auth.index')

@section('content')

<body>
  <div id="app">
    <section class="section">
      <div class="d-flex flex-wrap align-items-center justify-content-center min-vh-100">
        <div class="col-lg-4 col-md-6 col-12 bg-white">
          <div class="p-4 m-3">
            {{-- <img src="../assets/img/stisla-fill.svg" alt="logo" width="80" class="shadow-light rounded-circle mb-5 mt-2"> --}}
            <h4 class="text-dark font-weight-normal">Halo, selamat datang di <span class="font-weight-bold">{{ config('app.name') }}</span></h4>
<p class="text-muted">Silakan masuk untuk memulai petualangan baru!</p>
            <form method="POST" action="" class="needs-validation" novalidate="">
              @csrf
              <div class="form-group">
                <label for="email">Email</label>
                <input id="email" type="email" class="form-control" name="email" tabindex="1" required autofocus>
                <div class="invalid-feedback">
                  Please fill in your email
                </div>

                @error('email')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>

              <div class="form-group">
                <div class="d-block">
                  <label for="password" class="control-label">Password</label>
                </div>
                <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
                <div class="invalid-feedback">
                  Please fill in your password
                </div>

                @error('password')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>

              <div class="form-group text-right">
                <button type="submit" class="btn btn-primary btn-lg btn-icon icon-right" tabindex="4">
                  Login
                </button>
              </div>
            </form>

            {{-- <div class="text-center mt-5 text-small">
              Copyright &copy; Perpusweb. Made with 💙 by Stisla
            </div> --}}
          </div>
        </div>
        {{-- <div class="col-lg-8 col-12 order-lg-2 order-1 min-vh-100 background-walk-y position-relative overlay-gradient-bottom" data-background="../assets/img/unsplash/login-bg.jpg">
          <div class="absolute-bottom-left index-2">
            <div class="text-light p-5 pb-2">
              <div class="mb-5 pb-3">
                <h1 class="mb-2 display-4 font-weight-bold">Good Morning</h1>
                <h5 class="font-weight-normal text-muted-transparent">Bali, Indonesia</h5>
              </div> --}}
              {{-- Photo by <a class="text-light bb" target="_blank" href="https://unsplash.com/photos/a8lTjWJJgLA">Justin Kauffman</a> on <a class="text-light bb" target="_blank" href="https://unsplash.com">Unsplash</a> --}}
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
@endsection
