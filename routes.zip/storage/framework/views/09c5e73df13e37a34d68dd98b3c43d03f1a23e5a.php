<div class="main-sidebar">
  <aside id="sidebar-wrapper">
    <?php if(auth()->user()->id === 1 || auth()->user()->id === 2): ?>
    <div class="sidebar-brand">
      <a href="<?php echo e(route('admin.dashboard.index')); ?>"><?php echo e(config('app.name')); ?></a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="<?php echo e(route('admin.dashboard.index')); ?>"><?php echo e(Str::limit(config('app.name'), 2, '')); ?></a>
    </div>
    <ul class="sidebar-menu">
      <li class="<?php echo e(Request::segment(2) === 'dashboard' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.dashboard.index')); ?>"><i class="fas fa-fire"></i>
          <span>Dashboard</span></a>
      </li>
      <li class="menu-header">Data Master</li>
      <li class="<?php echo e(Request::segment(2) === 'users' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>"><i class="far fa-user"></i>
          <span>Siswa</span></a>
      </li>
      <li class="<?php echo e(Request::segment(2) === 'book-types' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.book-types.index')); ?>"><i class="far fa-bookmark"></i> <span>Kategori
            Buku</span></a>
      </li>
      <li class="<?php echo e(Request::segment(2) === 'books' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.books.index')); ?>"><i class="fas fa-book"></i> <span>Buku</span></a>
      </li>
      <li
        class="nav-item dropdown <?php echo e((Request::segment(2) === 'book-borrowers' ? 'active' : '') || Request::segment(2) === 'book-borrowers-history' ? 'active' : ''); ?>">
        <a href="#" class="nav-link has-dropdown"><i class="fas fa-book-reader"></i> <span>Peminjaman</span></a>
        <ul class="dropdown-menu">
          <li class="<?php echo e(Request::segment(2) === 'book-borrowers' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.book-borrowers.index')); ?>">Peminjam Buku</a>
          </li>
          <li class="<?php echo e(Request::segment(2) === 'book-borrowers-history' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.book-borrowers-history.index')); ?>">Histori Peminjam Buku</a>
          </li>
        </ul>
      </li>
      <?php else: ?>
      <div class="sidebar-brand">
        <a href="<?php echo e(route('anggota.dashboard.index')); ?>">Stisla</a>
      </div>
      <div class="sidebar-brand sidebar-brand-sm">
        <a href="<?php echo e(route('anggota.dashboard.index')); ?>">St</a>
      </div>
      <ul class="sidebar-menu">
        <li class="<?php echo e(Request::segment(2) === 'dashboard' ? 'active' : ''); ?>">
          <a class="nav-link" href="<?php echo e(route('anggota.dashboard.index')); ?>"><i class="fas fa-fire"></i>
            <span>Dashboard</span></a>
        </li>

        <li class="menu-header">Menu</li>
        <li
          class="nav-item dropdown <?php echo e((Request::segment(2) === 'book-borrowers' ? 'active' : '') || Request::segment(2) === 'book-borrowers-history' ? 'active' : ''); ?>">
          <a href="#" class="nav-link has-dropdown"><i class="fas fa-book-reader"></i> <span>Peminjaman</span></a>
          <ul class="dropdown-menu">
            <li class="<?php echo e(Request::segment(2) === 'book-borrowers-history' ? 'active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('anggota.book-borrowers-history.index')); ?>">Histori Peminjaman Buku</a>
            </li>
          </ul>
        </li>
      </ul>
      <?php endif; ?>
    </ul>

  </aside>
</div><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/layouts/stisla/sidebar.blade.php ENDPATH**/ ?>