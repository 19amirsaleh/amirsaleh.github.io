<!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="create-book-borrower-modal" data-backdrop="static" tabindex="-1"
  role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Tambah Data Peminjam Buku</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('admin.book-borrowers.store')); ?>" method="POST" id="book_borrower_form">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-lg-6">
              <div class="form-group">
                <label for="user_id">Pengguna</label>
                <select class="form-control" name="user_id" id="user_id_create" style="width: 100%;">
                  <option selected>Pilih Pengguna</option>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="form-group">
                <label for="book_id">Buku</label>
                <select class="form-control" name="book_id" id="book_id_create" style="width: 100%;">
                  <option selected>Pilih Buku</option>
                  <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-6">
              <label for="date_start">Dari Tanggal</label>
              <div class="input-group">
                <input type="date" class="form-control" name="date_start" id="date_start_create"
                  placeholder="Pilih tanggal mulai..">
                <div class="input-group-append">
                  <span class="input-group-text" id="basic-addon2"><i class="far fa-calendar-alt"></i></span>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <label for="date_end">Sampai Tanggal</label>
              <div class="input-group">
                <input type="date" class="form-control" name="date_end" id="date_end_create"
                  placeholder="Pilih tanggal akhir..">
                <div class="input-group-append">
                  <span class="input-group-text" id="basic-addon2"><i class="far fa-calendar-alt"></i></span>
                </div>
              </div>
            </div>

          </div>

          <div class="row">
            <div class="col-lg-12 pt-3">
              <div class="form-group">
                <label for="notes">Keterangan</label>
                <textarea class="form-control" name="notes" id="notes_create" rows="3"
                  placeholder="Masukkan keterangan.. (opsional)" style="height: 100px"></textarea>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-12">
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary" id="create-book-borrower-button">Tambah Data Peminjam
                  Buku</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/admin/book-borrowers/modal/book/create.blade.php ENDPATH**/ ?>