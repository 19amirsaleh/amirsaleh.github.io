<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 table-responsive">
    <?php echo $__env->make('layouts.utilities.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card px-3 py-3">
      <div class="row">
        <div class="col-lg-12 px-3 py-3 text-right">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#book-types-create-modal">
            Tambah Kategori Buku
          </button>
        </div>
      </div>
      <table class="table table-hovered text-center table-bordered" id="datatable">
        <thead>
          <tr>
            <th>#</th>
            <th>Nama Kategori</th>
            <th>Deskripsi</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $book_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td class="book-types-name-index"><?php echo e($book_type->name); ?></td>
            <td><?php echo e($book_type->description); ?></td>
            <td class="btn-group" role="group">
              <button type="submit" data-toggle="modal" data-target="#book-types-show-modal"
                data-id="<?php echo e($book_type->id); ?>" class="btn btn-sm btn-info book-types-swal-show-button">
                <i class="fas fa-info-circle"></i>
              </button>
              <button type="submit" data-toggle="modal" data-target="#book-types-edit-modal"
                data-id="<?php echo e($book_type->id); ?>" class="btn btn-sm btn-success book-types-swal-edit-button">
                <i class="fas fa-edit"></i>
              </button>
              <form action="<?php echo e(route('admin.book-types.destroy', $book_type->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <button type="submit" class="btn btn-sm btn-danger book-types-swal-delete-button">
                  <i class="fas fa-trash-alt"></i>
                </button>
              </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
<?php echo $__env->make('admin.book-types.modal.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.book-types.modal.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.book-types.modal.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<?php echo $__env->make('admin.book-types._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.stisla.index', ['title' => 'Daftar Kategori Buku', 'section_header' => 'Daftar Kategori Buku'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/admin/book-types/index.blade.php ENDPATH**/ ?>