<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 table-responsive">
    <div class="card px-3 py-3">
      <div class="row">
        <div class="col-lg-12 px-3 py-3 text-right">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#create-book-modal">
            Tambah Buku
          </button>
        </div>
      </div>
      <table class="table table-hovered text-center table-bordered" id="datatable">
        <thead>
          <tr>
            <th>#</th>
            <th>Nomor Buku</th>
            <th>Judul Buku</th>
            <th>Penerbit</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($book->book_number); ?></td>
            <td><?php echo e(Str::limit($book->title, 40, '...')); ?></td>
            <td><?php echo e($book->publisher); ?></td>
            <td>
              <a href="<?php echo e(route('admin.books.show', $book->id)); ?>" data-id="<?php echo e($book->id); ?>" class="btn btn-sm btn-info swal-show-a">
                <i class="fas fa-info-circle"></i>
              </a>
              <button type="submit" data-id="<?php echo e($book->id); ?>" class="btn btn-sm btn-danger swal-delete-button">
                <i class="fas fa-trash-alt"></i>
              </button>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
<?php echo $__env->make('admin.books.modal.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<?php echo $__env->make('admin.books._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.stisla.index', ['title' => 'Daftar Buku', 'section_header' => 'Daftar Buku'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/admin/books/index.blade.php ENDPATH**/ ?>