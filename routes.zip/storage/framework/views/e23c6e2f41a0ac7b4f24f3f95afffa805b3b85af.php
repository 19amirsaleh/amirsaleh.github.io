<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column align-items-center justify-content-center min-vh-10 text-center"> <div class="mb-4"> <img src="../assets/img/foto.png" alt="Foto Anda" class="rounded-circle" width="200" height="200"> </div> <h2 class="font-weight-bold">Amirudin Saleh</h2> <p class="text-muted">Kelas: <span class="font-weight-bold">SI503</span></p> <p class="text-muted">Mata Kuliah: <span class="font-weight-bold"> Pemograman Berbasis Web</span></p> </div>


  
  <!-- <div class="col-lg-4 col-md-4 col-sm-12">
    <div class="card card-statistic-2">
      <div class="card-chart">
        <canvas id="balance-chart" height="80"></canvas>
      </div>
      <div class="card-icon shadow-primary bg-primary">
        <i class="fas fa-book"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Balance</h4>
        </div>
        <div class="card-body">
          $187,13
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-4 col-sm-12">
    <div class="card card-statistic-2">
      <div class="card-chart">
        <canvas id="sales-chart" height="80"></canvas>
      </div>
      <div class="card-icon shadow-primary bg-primary">
        <i class="fas fa-shopping-bag"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Sales</h4>
        </div>
        <div class="card-body">
          4,732
        </div>
      </div>
    </div>
  </div> -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
<?php echo $__env->make('admin.dashboard.modal.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.stisla.index', ['title' => auth()->user()->id === 1 ? 'Admin Dashboard' : 'Operator Dashboard',
'section_header' => auth()->user()->id === 1 ? 'Admin Dashboard' : 'Operator Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>