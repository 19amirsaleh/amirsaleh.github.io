<?php echo $__env->make('layouts.stisla.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.stisla.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main Content -->
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1><?php echo e($section_header); ?></h1>
    </div>

    <div class="section-body">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </section>
</div>

<?php echo $__env->make('layouts.stisla.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/layouts/stisla/index.blade.php ENDPATH**/ ?>