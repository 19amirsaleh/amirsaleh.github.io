<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 table-responsive">
    <div class="card px-3 py-3">
      <table class="table table-hovered text-center table-bordered" id="datatable">
        <thead>
          <tr>
            <th>#</th>
            <th>Peminjam</th>
            <th>Buku</th>
            <th>Status</th>
            <th>Disetujui Pada</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $book_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($book_user->user->name); ?></td>
            <td><?php echo e(Str::limit($book_user->book->title, '40', '...')); ?></td>
            <?php if($book_user->status === 1): ?>
            <td class="badge badge-pill badge-success shadow-sm my-2" data-toggle="tooltip" data-placement="top" title="Disetujui">Disetujui</td>
            <?php else: ?>
            <td class="badge badge-pill badge-danger shadow-sm my-2" data-toggle="tooltip" data-placement="top" title="Tidak disetujui">Tidak disetujui</td>
            <?php endif; ?>
            <td><?php echo e(date_format(date_create($book_user->updated_at), 'd-m-Y, H:i')); ?></td>
            <td>
              <a href="<?php echo e(route('admin.book-borrowers-history.show', $book_user->id)); ?>" data-id="<?php echo e($book_user->id); ?>" class="btn btn-sm btn-info swal-show-a">
                <i class="fas fa-info-circle"></i>
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php echo $__env->make('admin.book-borrowers-history._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.stisla.index', ['title' => 'Histori Peminjaman Buku', 'section_header' => 'Histori Peminjaman Buku'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/admin/book-borrowers-history/index.blade.php ENDPATH**/ ?>