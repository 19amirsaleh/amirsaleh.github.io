<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 table-responsive">
    <div class="card px-3 py-3">
      <div class="row">
        <div class="col-lg-12 px-3 py-3 text-right">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#create-book-borrower-modal">
            Tambah Data Peminjam Buku
          </button>
        </div>
      </div>
      <table class="table table-hovered text-center table-bordered" id="datatable">
        <thead>
          <tr>
            <th>#</th>
            <th>Peminjam</th>
            <th>Buku</th>
            <th>Tanggal Mulai</th>
            <th>Tanggal Selesai</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $book_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($book_user->user->name); ?></td>
            <td><?php echo e(Str::limit($book_user->book->title, 40, '...')); ?></td>
            <td><?php echo e(date_format(date_create($book_user->date_start), 'd-m-Y')); ?></td>
            <td><?php echo e(date_format(date_create($book_user->date_end), 'd-m-Y')); ?></td>
            <td>
              <a href="<?php echo e(route('admin.book-borrowers.show', $book_user->id)); ?>" data-id="<?php echo e($book_user->id); ?>" class="btn btn-sm btn-info swal-show-a">
                <i class="fas fa-info-circle"></i>
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
<?php echo $__env->make('admin.book-borrowers.modal.book.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<?php echo $__env->make('admin.book-borrowers._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.stisla.index', ['title' => 'Daftar Peminjam Buku', 'section_header' => 'Daftar Peminjam Buku'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpusweb-master\resources\views/admin/book-borrowers/index.blade.php ENDPATH**/ ?>